# Dataset, attribution, and responsible use

## Dataset

This ZIP includes the public NASA C-MAPSS simulated turbofan-engine degradation dataset in `data/cmapss/`:

- `train_FD001.txt` through `train_FD004.txt`
- `test_FD001.txt` through `test_FD004.txt`
- `RUL_FD001.txt` through `RUL_FD004.txt`

Research basis: A. Saxena, K. Goebel, D. Simon, and N. Eklund, *Damage Propagation Modeling for Aircraft Engine Run-to-Failure Simulation*, PHM 2008.

## What the data represents

Each row is one simulated engine cycle. It contains an engine unit number, cycle number, three operating settings, and 21 sensor measurements. Training engines run to failure; test engines stop earlier and their residual RUL is supplied separately.

## Important limitations

- C-MAPSS is simulated benchmark data; it is not operational airline data.
- FD001 contains one operating condition and one fault mode.
- The Critical/Warning/Healthy bands in this project are prototype product settings, not aviation safety standards.
- The model must not automate a maintenance or flight-safety decision.
- A real deployment needs domain-expert validation, uncertainty estimates, data-quality checks, model-drift monitoring, audit logs, cybersecurity controls, and human approval.
