"""FastAPI service for AeroHealth RUL predictions."""

from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, field_validator

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from aerohealth.core import CAP_RUL, COLUMNS, final_cycle_features, risk_band  # noqa: E402


MODEL_PATH = ROOT / "models" / "aerohealth_hgb_fd001.joblib"

app = FastAPI(
    title="AeroHealth ML Service",
    description=(
        "NASA C-MAPSS FD001 prototype for aircraft-engine RUL prediction. "
        "Not a certified aircraft-maintenance system."
    ),
    version="1.0.0",
)


class SensorRecord(BaseModel):
    cycle: int = Field(gt=0, description="Positive operating-cycle number")
    operating_settings: list[float] = Field(description="Exactly three operating settings")
    sensors: list[float] = Field(description="Exactly 21 sensor readings")

    @field_validator("operating_settings")
    @classmethod
    def validate_operating_settings(cls, values: list[float]) -> list[float]:
        if len(values) != 3:
            raise ValueError("operating_settings must contain exactly 3 values")
        return values

    @field_validator("sensors")
    @classmethod
    def validate_sensors(cls, values: list[float]) -> list[float]:
        if len(values) != 21:
            raise ValueError("sensors must contain exactly 21 values")
        return values


class PredictRequest(BaseModel):
    engine_id: str = Field(min_length=1, max_length=100)
    records: list[SensorRecord] = Field(min_length=5, description="Chronological records for one engine")


class PredictResponse(BaseModel):
    engine_id: str
    predicted_rul_cycles: float
    maintenance_risk: str
    model_version: str
    notice: str


@lru_cache
def get_bundle() -> dict:
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model is missing. Run: python scripts/train.py")
    return joblib.load(MODEL_PATH)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ready" if MODEL_PATH.exists() else "model_missing",
        "model_path": str(MODEL_PATH.name),
    }


@app.post("/predict", response_model=PredictResponse)
def predict(request: PredictRequest) -> PredictResponse:
    try:
        records = sorted(request.records, key=lambda record: record.cycle)
        if len({record.cycle for record in records}) != len(records):
            raise ValueError("cycles must be unique for one engine")
        rows = [
            [1, record.cycle, *record.operating_settings, *record.sensors]
            for record in records
        ]
        df = pd.DataFrame(rows, columns=COLUMNS)
        bundle = get_bundle()
        features = final_cycle_features(df, bundle["feature_columns"])
        predicted = float(np.clip(bundle["model"].predict(features)[0], 0, CAP_RUL))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:  # Request-level error without exposing a traceback.
        raise HTTPException(status_code=500, detail=f"Prediction failed: {exc}") from exc

    return PredictResponse(
        engine_id=request.engine_id,
        predicted_rul_cycles=round(predicted, 2),
        maintenance_risk=risk_band(predicted),
        model_version=bundle["model_version"],
        notice="Prototype result from simulated NASA C-MAPSS data; human review is required.",
    )
