"""Feature preparation and shared rules for the AeroHealth ML baseline."""

from __future__ import annotations

import pandas as pd


CAP_RUL = 125
SENSOR_COLUMNS = [f"s{i}" for i in range(1, 22)]
COLUMNS = ["unit", "cycle", "op1", "op2", "op3", *SENSOR_COLUMNS]


def read_cmapss(path: str) -> pd.DataFrame:
    """Read one NASA C-MAPSS whitespace-delimited data file."""
    return pd.read_csv(path, sep=r"\s+", header=None, names=COLUMNS)


def add_features(df: pd.DataFrame, with_training_rul: bool = False) -> pd.DataFrame:
    """Create the transparent 85-feature table used by the reported baseline.

    For every sensor this keeps the current value, adds a difference from the
    first-five-cycle engine baseline, a 20-cycle rolling mean, and a 20-cycle
    rolling standard deviation. The operating cycle is retained as feature 85.
    """
    work = df.copy().sort_values(["unit", "cycle"]).reset_index(drop=True)
    if with_training_rul:
        work["rul"] = work.groupby("unit")["cycle"].transform("max") - work["cycle"]
        work["rul"] = work["rul"].clip(upper=CAP_RUL)

    baseline = (
        work[work["cycle"] <= 5]
        .groupby("unit")[SENSOR_COLUMNS]
        .mean()
        .add_suffix("_baseline")
    )
    work = work.join(baseline, on="unit")
    for sensor in SENSOR_COLUMNS:
        work[f"{sensor}_delta"] = work[sensor] - work[f"{sensor}_baseline"]
        grouped = work.groupby("unit")[sensor]
        work[f"{sensor}_mean20"] = grouped.transform(
            lambda values: values.rolling(20, min_periods=1).mean()
        )
        work[f"{sensor}_std20"] = grouped.transform(
            lambda values: values.rolling(20, min_periods=2).std().fillna(0)
        )
    return work


def feature_columns() -> list[str]:
    """Return the stable feature order used for model training and inference."""
    columns = list(SENSOR_COLUMNS)
    for sensor in SENSOR_COLUMNS:
        columns.extend([f"{sensor}_delta", f"{sensor}_mean20", f"{sensor}_std20"])
    return [*columns, "cycle"]


def final_cycle_features(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    """Build a single model-ready row from one engine's sensor history."""
    featured = add_features(df, with_training_rul=False)
    last_row = featured.sort_values(["unit", "cycle"]).groupby("unit").tail(1)
    return last_row.loc[:, columns].replace([float("inf"), float("-inf")], 0).fillna(0)


def risk_band(rul_cycles: float) -> str:
    """Map predicted RUL to the documented prototype alert bands."""
    if rul_cycles <= 30:
        return "Critical"
    if rul_cycles <= 60:
        return "Warning"
    return "Healthy"
