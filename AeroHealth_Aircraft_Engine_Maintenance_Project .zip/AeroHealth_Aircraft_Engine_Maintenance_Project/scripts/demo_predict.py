"""Run a local AeroHealth prediction from the included FD001 test data."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import joblib
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from aerohealth.core import CAP_RUL, feature_columns, final_cycle_features, read_cmapss, risk_band  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", type=int, default=1, help="FD001 test engine ID (1-100)")
    args = parser.parse_args()

    data = read_cmapss(str(ROOT / "data" / "cmapss" / "test_FD001.txt"))
    engine = data[data["unit"] == args.engine].copy()
    if engine.empty:
        raise SystemExit("Engine not found. Choose an ID between 1 and 100.")
    bundle = joblib.load(ROOT / "models" / "aerohealth_hgb_fd001.joblib")
    features = final_cycle_features(engine, bundle["feature_columns"])
    rul = float(np.clip(bundle["model"].predict(features)[0], 0, CAP_RUL))
    response = {
        "engine_id": f"FD001-test-{args.engine}",
        "last_observed_cycle": int(engine["cycle"].max()),
        "predicted_rul_cycles": round(rul, 2),
        "maintenance_risk": risk_band(rul),
        "model_version": bundle["model_version"],
    }
    print(json.dumps(response, indent=2))


if __name__ == "__main__":
    main()
