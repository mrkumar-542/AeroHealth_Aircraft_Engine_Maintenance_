"""Train and evaluate the reproducible AeroHealth FD001 baseline."""

from __future__ import annotations

import json
import random
import sys
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from aerohealth.core import CAP_RUL, add_features, feature_columns, read_cmapss, risk_band  # noqa: E402


SEED = 42
DATA = ROOT / "data" / "cmapss"
MODELS = ROOT / "models"
OUT = ROOT / "outputs"
FIGURES = OUT / "figures"


def as_risk(values: pd.Series) -> pd.Series:
    return values.map(risk_band)


def main() -> None:
    random.seed(SEED)
    np.random.seed(SEED)
    MODELS.mkdir(exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)

    train = add_features(read_cmapss(str(DATA / "train_FD001.txt")), with_training_rul=True)
    test = add_features(read_cmapss(str(DATA / "test_FD001.txt")))
    target = pd.read_csv(DATA / "RUL_FD001.txt", sep=r"\s+", header=None, names=["actual_rul"])

    columns = feature_columns()
    x_train = train[columns].replace([np.inf, -np.inf], np.nan).fillna(0)
    y_train = train["rul"]
    test_last = test.sort_values(["unit", "cycle"]).groupby("unit").tail(1).sort_values("unit").reset_index(drop=True)
    x_test = test_last[columns].replace([np.inf, -np.inf], np.nan).fillna(0)
    y_test = target["actual_rul"].clip(upper=CAP_RUL).to_numpy()

    models = {
        "Random Forest": RandomForestRegressor(
            n_estimators=250, max_depth=18, min_samples_leaf=2, random_state=SEED, n_jobs=-1
        ),
        "Histogram Gradient Boosting": HistGradientBoostingRegressor(
            max_iter=300, learning_rate=0.06, max_leaf_nodes=31, l2_regularization=0.1, random_state=SEED
        ),
    }
    predictions, metrics = {}, []
    for name, model in models.items():
        model.fit(x_train, y_train)
        predicted = np.clip(model.predict(x_test), 0, CAP_RUL)
        predictions[name] = predicted
        metrics.append({
            "model": name,
            "mae_cycles": round(float(mean_absolute_error(y_test, predicted)), 4),
            "rmse_cycles": round(float(mean_squared_error(y_test, predicted) ** 0.5), 4),
        })

    metrics_df = pd.DataFrame(metrics).sort_values("rmse_cycles").reset_index(drop=True)
    best_name = str(metrics_df.loc[0, "model"])
    best_prediction = predictions[best_name]
    best_model = models[best_name]
    joblib.dump(
        {"model": best_model, "feature_columns": columns, "model_version": "hgb-fd001-v1"},
        MODELS / "aerohealth_hgb_fd001.joblib",
    )

    results = pd.DataFrame({
        "engine": test_last["unit"].to_numpy(),
        "actual_rul": y_test,
        "predicted_rul": best_prediction,
    })
    results["actual_risk"] = as_risk(results["actual_rul"])
    results["predicted_risk"] = as_risk(results["predicted_rul"])
    results["absolute_error"] = (results["actual_rul"] - results["predicted_rul"]).abs()
    results.to_csv(OUT / "test_predictions.csv", index=False)
    metrics_df.to_csv(OUT / "metrics.csv", index=False)

    summary = {
        "dataset": "NASA C-MAPSS FD001 (simulated)",
        "seed": SEED,
        "train_rows": int(len(train)),
        "train_engines": int(train["unit"].nunique()),
        "test_engines": int(len(results)),
        "feature_count": len(columns),
        "selected_model": best_name,
        "metrics": metrics,
        "risk_bands": {"Critical": "0-30", "Warning": "31-60", "Healthy": "61-125"},
    }
    (OUT / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    sns.set_theme(style="whitegrid")
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.hist(train["rul"], bins=35, color="#176B87", edgecolor="white")
    ax.set(title="Training RUL Distribution (FD001)", xlabel="Capped RUL cycles", ylabel="Records")
    fig.tight_layout(); fig.savefig(FIGURES / "rul_distribution.png", dpi=180); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 5.2))
    ax.scatter(y_test, best_prediction, color="#176B87", alpha=0.8)
    ax.plot([0, CAP_RUL], [0, CAP_RUL], "--", color="#D64933")
    ax.set(title=f"Actual vs Predicted RUL ({best_name})", xlabel="Actual RUL", ylabel="Predicted RUL")
    fig.tight_layout(); fig.savefig(FIGURES / "actual_vs_predicted.png", dpi=180); plt.close(fig)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
